﻿╔═══════════════════════════════╗
║           DocScript           ║
╚═══════════════════════════════╝

DocScript in a simple, procedural Programming-Language.

There are four key files to pay attention to:
	- DocScript.Library.dll		(Core Interpretation Logic)
	- DSCLI.EXE			(DS Command-Line Interpreter. Use the /? argument.)
	- DSIDE.EXE			(DS Windows GUI IDE)
	- _CreateEntireDB.SQL		(Read the comments herein for DS-Interactive setup guidance)

(Use Everything-Search to find said files in the solution)

Did you really just make it all the way to the end of this README?
Well done.
BM (c) 2023.