﻿╔══════════════════════════════════════╗
║      MullNet System Utilities...     ║
╚══════════════════════════════════════╝
...can be used for System Automation, Productivity, and Networking.

--------------- Binaries ---------------
AutoEMail.exe				Windows		Bulk EMail sender
BaseConverter.exe			Windows		Place value base converter
CLAOutputter.exe			Console		Outputs the Command-Line Arguments fed into it (Useful for working out what CLAs are being passed to something)
ColourScreen.exe			Con/Win		Example: "ColourScreen.exe Blue". (Useful for Projectors)
EmptyFolderDel.exe			Windows		Finds and can delete empty folders within a directory
Screenshotter.exe			Con/Win		Example: "Screenshotter Shot.PNG". Takes a Screenshot and saves it as "Shot.PNG" in the current directory
IntervalScreenshotter.exe		Con/Win		Example: "IntervalScrnshotr.exe Shots\ 5 30". The example innvokation would save a Screenshot to the "Shots\" Folder every 5 seconds, and overwrite the oldest file after creating 30 screenshot files
PolygonCircles.exe			Windows		Plots polygons within circles to create interesting artwork
IP.exe					Console		Prints the Workstation's IP Address to the Console
MD5Hasher.exe				Windows		Produces the MD5 Hash of a string (For Demonstration and testing)
MNKeyCommands.exe			Windows		Listens for Win + (C, I, N, Shift + N) KeyPresses, launching CMD, IPInfo, Notepad, and Notepad++ respectively.
Sleep.exe				Windows		Initiates an ACPI Sleep on the Workstation. Not all environments support Sleep mode
MsgBoxGen.exe				Windows		Generates a .vbs file to display a MsgBox
WebGet.exe				Console		Example: "WebGet.exe http://example.com/". Downloads the text response from the HTTP EndPoint, printing it onto the Console

MouseGone32.exe				Windows		(C++/Win32) Hides the Mouse Pointer on the current session
Beep32.exe				Windows		(C++/Win32) Beeps through the Soundcard, or - failing that - the PC Speaker (For Demonstration and testing)